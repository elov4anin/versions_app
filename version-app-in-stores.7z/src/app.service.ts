import { Injectable } from '@nestjs/common';
import * as gplay from 'google-play-scraper';

@Injectable()
export class AppService {
  async getVersionCodeFromGoogle(appId): Promise<string> {
    const result = await gplay.app({ appId });
    return JSON.stringify({
      version: result.version,
    });
  }
}
