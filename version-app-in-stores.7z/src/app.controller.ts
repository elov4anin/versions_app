import { Controller, Get, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { Request } from 'express';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('versions')
  async getVersionCode(@Req() request: Request): Promise<string> {
    console.log('test mehotd', request.query);
    const bundleName = request.query.bundleName;
    return await this.appService.getVersionCodeFromGoogle(bundleName);
  }
}
